﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace TreeAVL
{
    public partial class Form1 : Form
    {
        Bitmap bitmap;
        Graphics graph;
        TreeAVL tree;
        Node selectNode;
        DrawTreeAVL draw;
        Stopwatch sw;
        public Label []lb;
        List<int> listvalue=new List<int> ();

        public int[] KeyArr;        // Mảng chứa các key của cây
        public float[,] PosArr, PosArr2;
        public int n;              // Số phần tử của mảng
        public int r = 16; 
        public int R = 16;
        int value;

        public Form1()
        {
            InitializeComponent();
            bitmap = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            graph = Graphics.FromImage(bitmap);
            graph.CompositingQuality = CompositingQuality.HighQuality;
            pictureBox1.Image = bitmap;
            pictureBox1.Show();
            draw = new DrawTreeAVL();
          //  groupPanel2.Enabled = false;
        }
        //
        public void GetPos()
        {
            tree.root.x = pictureBox1.Width / 2;
            tree.root.y = 45;
            tree.root.Father = pictureBox1.Width;
            tree.root.GetPos(tree.root.pLeft, this);
            tree.root.GetPos(tree.root.pRight, this);
        }
        //
        public void UpdateDel(int delKey)
        {
            int[] newArr = new int[n - 1];
            for (int i = 0; i < n - 1; i++)
            {
                if (KeyArr[i] != delKey)
                    newArr[i] = KeyArr[i];
            }
            KeyArr = new int[--n];
            KeyArr = newArr;
        }
        //
        public void LoadPos(Node root, float[,] PosArr)
        {
            for (int j = 0; j < KeyArr.Length; j++)
            {
                if (root.key == (int)PosArr[j, 0])
                {
                    root.x = PosArr[j, 1]; root.y = PosArr[j, 2]; //root.Father = PosArr[j, 3];
                    break;
                }
            }
            if (root.pLeft != null)
                LoadPos(root.pLeft, PosArr);
            if (root.pRight != null)
                LoadPos(root.pRight, PosArr);
        }
        //
        public void UpdateAdd(int value)
        {
            n++;
            int[] newArr = new int[n];
            for (int i = 0; i < n - 1; i++)
                newArr[i] = KeyArr[i];
            newArr[n - 1] = value;
            KeyArr = new int[n];
            KeyArr = newArr;
        }
        //
        public void SavePos(Node root, float[,] PosArr, ref int i)
        {
            if (root != null)
            {
                PosArr[i, 0] = (float)root.key; PosArr[i, 1] = root.x; PosArr[i, 2] = root.y; PosArr[i++, 3] = root.Father;
                if (root.pLeft != null)
                    SavePos(root.pLeft, PosArr, ref i);
                if (root.pRight != null)
                    SavePos(root.pRight, PosArr, ref i);
            }
        }
        //
       

            // Thêm node
        private void txtValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void btnAddNode_Click(object sender, EventArgs e)
        {
            if (txtValue.Text == String.Empty)
            {
                MessageBox.Show("Chưa nhập giá trị nút!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                sw = new Stopwatch();
                sw.Start();
                int value = Convert.ToInt32(txtValue.Text.ToString());
                listvalue.Add(value);
                //textBox1.Text = textBox1.Text +"   " + value;
                if (tree == null)
                {
                    tree = new TreeAVL();
                    tree.insertNode(ref tree.root, value, tree, draw, graph, bitmap, this);
                    UpdateAdd(value);

                    tree.root.x = pictureBox1.Width / 2;
                    tree.root.y = 45;
                    tree.root.Father = pictureBox1.Width;

                    graph.SmoothingMode = SmoothingMode.HighQuality;
                    float x = 15, y = 45;
                    draw.DrawNode(value, 15, 45, graph, bitmap, this);
                    pictureBox1.Image = bitmap;
                    while (x < (pictureBox1.Width / 2))
                    {
                        x += 2; if (x > pictureBox1.Width / 2) x = pictureBox1.Width / 2;

                        graph.Clear(Color.Honeydew);
                        draw.DrawNode(value, x, y, graph, bitmap, this);
                        Thread.Sleep(1);
                        Application.DoEvents();
                        pictureBox1.Image = bitmap;
                    }

                    graph.Clear(Color.Honeydew);
                    draw.DrawTree(tree, graph, bitmap, this);
                    pictureBox1.Image = bitmap;

                    selectNode = tree.root;
                    draw.DrawSelectNode(selectNode, graph, bitmap, this);
                    pictureBox1.Image = bitmap;


                }
                else
                {
                    selectNode = tree.root;
                    int i = 0;
                    float[,] PosArr = new float[KeyArr.Length + 1, 4];
                    SavePos(tree.root, PosArr, ref i);

                    int k = tree.insertNode(ref tree.root, value, tree, draw, graph, bitmap, this);

                    PosArr[i, 0] = (float)value; PosArr[i, 1] = tree.xAdd; PosArr[i, 2] = tree.yAdd; PosArr[i++, 3] = tree.xFatherAdd;

                    float[,] PosArr2 = new float[KeyArr.Length + 1, 4];
                    if (k != 0)
                    {
                        UpdateAdd(value);

                        tree.root.x = pictureBox1.Width / 2;
                        tree.root.y = 45;
                        tree.root.Father = pictureBox1.Width;
                        tree.root.GetPos(tree.root.pLeft, this);
                        tree.root.GetPos(tree.root.pRight, this);

                        i = 0;
                        SavePos(tree.root, PosArr2, ref i);
                        LoadPos(tree.root, PosArr);

                        draw.MoveNode(ref tree, PosArr2, graph, bitmap, this);

                        MessageBox.Show("Thêm thành công!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show("node đã tồn tại, vui lòng thêm node khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    graph.Clear(Color.Honeydew);
                    draw.DrawTree(tree, graph, bitmap, this);
                    pictureBox1.Image = bitmap;

                    selectNode = tree.root;
                    draw.DrawSelectNode(selectNode, graph, bitmap, this);
                    pictureBox1.Image = bitmap;
                }
                sw.Stop();
            }
            //labelX5.Text = sw.Elapsed.ToString();
        }

        // xóa node
        private void btnDeleteNode_Click(object sender, EventArgs e)
        {
            if (txtValue.Text == String.Empty)
            {
                MessageBox.Show("Chưa nhập giá trị nút cần xóa!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                sw = new Stopwatch();
                sw.Start();
                value = Convert.ToInt32(txtValue.Text.ToString());
                PosArr = new float[KeyArr.Length, 4];
                int i = 0;
                SavePos(tree.root, PosArr, ref i);
                draw.DrawNode(value, tree.root.x, tree.root.y, graph, bitmap, this);

                tree.delNode(ref tree.root, value, tree, draw, graph, bitmap, this);

                UpdateDel(value);

                if (tree.root == null)
                {
                    graph.Clear(Color.Honeydew);
                    pictureBox1.Image = bitmap;

                }
                else
                {

                    GetPos();

                    PosArr2 = new float[KeyArr.Length, 4]; i = 0;
                    SavePos(tree.root, PosArr2, ref i);
                    LoadPos(tree.root, PosArr);

                    draw.MoveNode(ref tree, PosArr2, graph, bitmap, this);

                    graph.Clear(Color.Honeydew);
                    draw.DrawTree(tree, graph, bitmap, this);

                    selectNode = tree.root;
                    draw.DrawSelectNode(selectNode, graph, bitmap, this);
                    pictureBox1.Image = bitmap;
                    MessageBox.Show("Xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                sw.Stop();
            }
           // labelX5.Text = sw.Elapsed.ToString();

        }

        private void Delete(int value)
        {
            value = Convert.ToInt32(txtValue.Text.ToString());
            //string s = textBox1.Text;
            //textBox1.Text = s.Replace(txtValue.Text, " ");
            PosArr = new float[KeyArr.Length, 4];
            int i = 0;
            SavePos(tree.root, PosArr, ref i);
            draw.DrawNode(value, tree.root.x, tree.root.y, graph, bitmap, this);

            tree.delNode(ref tree.root, value, tree, draw, graph, bitmap, this);

            UpdateDel(value);

            if (tree.root == null)
            {
                graph.Clear(Color.Honeydew);
                pictureBox1.Image = bitmap;

            }
            else
            {

                GetPos();

                PosArr2 = new float[KeyArr.Length, 4]; i = 0;
                SavePos(tree.root, PosArr2, ref i);
                LoadPos(tree.root, PosArr);

                draw.MoveNode(ref tree, PosArr2, graph, bitmap, this);

                graph.Clear(Color.Honeydew);
                draw.DrawTree(tree, graph, bitmap, this);

                selectNode = tree.root;
                draw.DrawSelectNode(selectNode, graph, bitmap, this);
                pictureBox1.Image = bitmap;
                MessageBox.Show("Xóa thành công!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // tìm node
        private void btnSearchNode_Click(object sender, EventArgs e)
        {
            if (txtValue.Text == String.Empty)
            {
                MessageBox.Show("Chưa nhập giá trị số cân tìm!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                //graph.Clear(Color.Honeydew);
                //gan
                Node p = new Node();
                sw = new Stopwatch();
                sw.Start();
                value = Convert.ToInt32(txtValue.Text.ToString());
                p = tree.SearchNode(value, tree.root, graph, bitmap, draw, tree, this);


                //
                graph.Clear(Color.Honeydew);
                draw.DrawTree(tree, graph, bitmap, this);
                pictureBox1.Image = bitmap;

                if (p == null)
                {
                    selectNode = tree.root;//GÁN SELECTNODE LÀ ROOT
                    Thread.Sleep(100);
                    MessageBox.Show("Node không tồn tại!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    selectNode = tree.root;
                    draw.DrawSelectNode(tree.root, graph, bitmap, this);
                }
                else
                {
                    selectNode = p; // Gan selectNode la Node vua moi tim thay

                    tree.HieuUng(selectNode, draw, graph, bitmap, this);

                    MessageBox.Show("Đã tìm thấy node!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                sw.Stop();
                // labelX5.Text = sw.Elapsed.ToString();
                // MessageBox.Show("Đã tìm thấy node!!!","Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        // tạo node
        private void btnCreate_Click(object sender, EventArgs e)
        {
            tree = new TreeAVL();
            graph.Clear(Color.Honeydew);
            Refresh();


        }

        private void CreateNode()
        {
            value = Convert.ToInt32(textBoxX1.Text.ToString());
            //textBox1.Text = textBox1.Text + "     " + value;
            listvalue.Add(value);
            if (tree == null)
            {
                tree = new TreeAVL();
                tree.insertNode(ref tree.root, value, tree, draw, graph, bitmap, this);
                UpdateAdd(value);

                tree.root.x = pictureBox1.Width / 2;
                tree.root.y = 45;
                tree.root.Father = pictureBox1.Width;

                graph.SmoothingMode = SmoothingMode.HighQuality;
                float x = 15, y = 45;
                draw.DrawNode(value, 15, 45, graph, bitmap, this);
                pictureBox1.Image = bitmap;
                while (x < (pictureBox1.Width / 2))
                {
                    x += 2; if (x > pictureBox1.Width / 2) x = pictureBox1.Width / 2;

                    graph.Clear(Color.Honeydew);
                    draw.DrawNode(value, x, y, graph, bitmap, this);
                    Thread.Sleep(1);
                    Application.DoEvents();
                    pictureBox1.Image = bitmap;
                }

                graph.Clear(Color.Honeydew);
                draw.DrawTree(tree, graph, bitmap, this);
                pictureBox1.Image = bitmap;

                selectNode = tree.root;
                draw.DrawSelectNode(selectNode, graph, bitmap, this);
                pictureBox1.Image = bitmap;
            }
            else
            {
                selectNode = tree.root;
                int i = 0;
                float[,] PosArr = new float[KeyArr.Length + 1, 4];
                SavePos(tree.root, PosArr, ref i);

                int k = tree.insertNode(ref tree.root, value, tree, draw, graph, bitmap, this);

                PosArr[i, 0] = (float)value; PosArr[i, 1] = tree.xAdd; PosArr[i, 2] = tree.yAdd; PosArr[i++, 3] = tree.xFatherAdd;

                float[,] PosArr2 = new float[KeyArr.Length + 1, 4];

                if (k != 0)
                {
                    UpdateAdd(value);

                    GetPos();

                    i = 0;
                    SavePos(tree.root, PosArr2, ref i);
                    LoadPos(tree.root, PosArr);

                    draw.MoveNode(ref tree, PosArr2, graph, bitmap, this);
                }

                graph.Clear(Color.Honeydew);
                draw.DrawTree(tree, graph, bitmap, this);
                pictureBox1.Image = bitmap;

                selectNode = tree.root;
                draw.DrawSelectNode(selectNode, graph, bitmap, this);
                pictureBox1.Image = bitmap;

            }
            
            //groupPanel2.Enabled = true;
            textBoxX1.Text = "";
        }

       
        private void textBoxX1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(@"
- Nhập giá trị Node cho cây -> tạo Node
hoặc
- Nhập số lượng node -> tạo ngẫu nhiên
- Nhập giá trị muốn thao tác trên cây: thêm, tìm kiếm, xóa.
- LH(-1): cây con trái cao hơn
- EH(0) : cây con trái bằng cây con phải
- RH(1) : cây con phải cao hơn
","Hướng dẫn",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnRandom_Click(object sender, EventArgs e)
        {
            if (textBoxX1.Text == String.Empty)
            {
                MessageBox.Show("Chưa nhập số lượng nút!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                panel2.Enabled = false;
                panel3.Enabled = false;
                sw = new Stopwatch();
                sw.Start();
                int n = Convert.ToInt32(textBoxX1.Text.ToString());
                Random r = new Random();
                for (int j = 0; j < n; j++)
                {
                    int addKey = r.Next(99);
                    listvalue.Add(addKey);
                    if (tree == null)
                    {
                        tree = new TreeAVL();
                        tree.insertNode(ref tree.root, addKey, tree, draw, graph, bitmap, this);
                        UpdateAdd(addKey);

                        tree.root.x = pictureBox1.Width / 2;
                        tree.root.y = 45;
                        tree.root.Father = pictureBox1.Width;

                        graph.SmoothingMode = SmoothingMode.HighQuality;
                        float x = 15, y = 45;
                        draw.DrawNode(addKey, 15, 45, graph, bitmap, this);
                        pictureBox1.Image = bitmap;
                        while (x < (pictureBox1.Width / 2))
                        {
                            x += 2; if (x > pictureBox1.Width / 2) x = pictureBox1.Width / 2;

                            graph.Clear(Color.Honeydew);
                            draw.DrawNode(addKey, x, y, graph, bitmap, this);
                            Thread.Sleep(1);
                            Application.DoEvents();
                            pictureBox1.Image = bitmap;
                        }

                        graph.Clear(Color.Honeydew);
                        draw.DrawTree(tree, graph, bitmap, this);
                        pictureBox1.Image = bitmap;

                        selectNode = tree.root;
                        draw.DrawSelectNode(selectNode, graph, bitmap, this);
                        pictureBox1.Image = bitmap;

                    }
                    else
                    {
                        selectNode = tree.root;
                        int i = 0;
                        float[,] PosArr = new float[KeyArr.Length + 1, 4];
                        SavePos(tree.root, PosArr, ref i);

                        int k = tree.insertNode(ref tree.root, addKey, tree, draw, graph, bitmap, this);

                        PosArr[i, 0] = (float)addKey; PosArr[i, 1] = tree.xAdd; PosArr[i, 2] = tree.yAdd; PosArr[i++, 3] = tree.xFatherAdd;

                        float[,] PosArr2 = new float[KeyArr.Length + 1, 4];

                        if (k != 0)
                        {
                            UpdateAdd(addKey);

                            GetPos();

                            i = 0;
                            SavePos(tree.root, PosArr2, ref i);
                            LoadPos(tree.root, PosArr);

                            draw.MoveNode(ref tree, PosArr2, graph, bitmap, this);
                        }

                        graph.Clear(Color.Honeydew);
                        draw.DrawTree(tree, graph, bitmap, this);
                        pictureBox1.Image = bitmap;

                        selectNode = tree.root;
                        draw.DrawSelectNode(selectNode, graph, bitmap, this);
                        pictureBox1.Image = bitmap;

                    }
                }

                sw.Stop();
                // labelX5.Text = sw.Elapsed.ToString();
                btnSearchNode.Enabled = true;
                btnAddNode.Enabled = true;
                btnDeleteNode.Enabled = true;
                panel2.Enabled = true;
                panel3.Enabled = true;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Thongtin t = new Thongtin();
            t.Show();
        }

    }
}
