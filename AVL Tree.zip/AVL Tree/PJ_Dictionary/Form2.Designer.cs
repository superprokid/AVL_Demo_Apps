﻿namespace PJ_Dictionary
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_word = new System.Windows.Forms.TextBox();
            this.tbx_wordType = new System.Windows.Forms.TextBox();
            this.tbx_mean3 = new System.Windows.Forms.TextBox();
            this.tbx_mean2 = new System.Windows.Forms.TextBox();
            this.tbx_mean1 = new System.Windows.Forms.TextBox();
            this.btn_updateTree = new System.Windows.Forms.Button();
            this.btn_updateFile = new System.Windows.Forms.Button();
            this.lb_word = new System.Windows.Forms.Label();
            this.lb_wordType = new System.Windows.Forms.Label();
            this.lb_mean = new System.Windows.Forms.Label();
            this.tbx_mean5 = new System.Windows.Forms.TextBox();
            this.tbx_mean4 = new System.Windows.Forms.TextBox();
            this.tbx_pronunciation = new System.Windows.Forms.TextBox();
            this.lb_pronunciation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_word
            // 
            this.tbx_word.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_word.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_word.Location = new System.Drawing.Point(271, 189);
            this.tbx_word.Name = "tbx_word";
            this.tbx_word.Size = new System.Drawing.Size(245, 28);
            this.tbx_word.TabIndex = 0;
            // 
            // tbx_wordType
            // 
            this.tbx_wordType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_wordType.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_wordType.Location = new System.Drawing.Point(270, 305);
            this.tbx_wordType.Name = "tbx_wordType";
            this.tbx_wordType.Size = new System.Drawing.Size(245, 28);
            this.tbx_wordType.TabIndex = 1;
            // 
            // tbx_mean3
            // 
            this.tbx_mean3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_mean3.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mean3.Location = new System.Drawing.Point(270, 446);
            this.tbx_mean3.Name = "tbx_mean3";
            this.tbx_mean3.Size = new System.Drawing.Size(245, 28);
            this.tbx_mean3.TabIndex = 2;
            // 
            // tbx_mean2
            // 
            this.tbx_mean2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_mean2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mean2.Location = new System.Drawing.Point(270, 404);
            this.tbx_mean2.Name = "tbx_mean2";
            this.tbx_mean2.Size = new System.Drawing.Size(245, 28);
            this.tbx_mean2.TabIndex = 3;
            // 
            // tbx_mean1
            // 
            this.tbx_mean1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_mean1.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mean1.Location = new System.Drawing.Point(270, 362);
            this.tbx_mean1.Name = "tbx_mean1";
            this.tbx_mean1.Size = new System.Drawing.Size(245, 28);
            this.tbx_mean1.TabIndex = 4;
            // 
            // btn_updateTree
            // 
            this.btn_updateTree.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_updateTree.AutoSize = true;
            this.btn_updateTree.BackColor = System.Drawing.Color.Transparent;
            this.btn_updateTree.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_updateTree.FlatAppearance.BorderSize = 2;
            this.btn_updateTree.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btn_updateTree.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_updateTree.Location = new System.Drawing.Point(619, 189);
            this.btn_updateTree.Name = "btn_updateTree";
            this.btn_updateTree.Size = new System.Drawing.Size(169, 33);
            this.btn_updateTree.TabIndex = 5;
            this.btn_updateTree.Text = "Cập nhật vào cây...";
            this.btn_updateTree.UseVisualStyleBackColor = false;
            this.btn_updateTree.Click += new System.EventHandler(this.Btn_updateTree_Click);
            // 
            // btn_updateFile
            // 
            this.btn_updateFile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_updateFile.AutoSize = true;
            this.btn_updateFile.BackColor = System.Drawing.Color.Transparent;
            this.btn_updateFile.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_updateFile.FlatAppearance.BorderSize = 2;
            this.btn_updateFile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btn_updateFile.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_updateFile.Location = new System.Drawing.Point(619, 245);
            this.btn_updateFile.Name = "btn_updateFile";
            this.btn_updateFile.Size = new System.Drawing.Size(168, 33);
            this.btn_updateFile.TabIndex = 6;
            this.btn_updateFile.Text = "Cập nhật vào file...";
            this.btn_updateFile.UseVisualStyleBackColor = false;
            this.btn_updateFile.Click += new System.EventHandler(this.Btn_updateFile_Click);
            // 
            // lb_word
            // 
            this.lb_word.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_word.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lb_word.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lb_word.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_word.Location = new System.Drawing.Point(154, 189);
            this.lb_word.Name = "lb_word";
            this.lb_word.Size = new System.Drawing.Size(92, 27);
            this.lb_word.TabIndex = 7;
            this.lb_word.Text = "Từ:";
            this.lb_word.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_wordType
            // 
            this.lb_wordType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_wordType.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lb_wordType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lb_wordType.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_wordType.Location = new System.Drawing.Point(153, 304);
            this.lb_wordType.Name = "lb_wordType";
            this.lb_wordType.Size = new System.Drawing.Size(92, 27);
            this.lb_wordType.TabIndex = 8;
            this.lb_wordType.Text = "Từ loại:";
            this.lb_wordType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_mean
            // 
            this.lb_mean.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_mean.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lb_mean.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lb_mean.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mean.Location = new System.Drawing.Point(153, 362);
            this.lb_mean.Name = "lb_mean";
            this.lb_mean.Size = new System.Drawing.Size(92, 27);
            this.lb_mean.TabIndex = 9;
            this.lb_mean.Text = "Nghĩa:";
            this.lb_mean.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbx_mean5
            // 
            this.tbx_mean5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_mean5.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mean5.Location = new System.Drawing.Point(270, 532);
            this.tbx_mean5.Name = "tbx_mean5";
            this.tbx_mean5.Size = new System.Drawing.Size(245, 28);
            this.tbx_mean5.TabIndex = 2;
            // 
            // tbx_mean4
            // 
            this.tbx_mean4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_mean4.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mean4.Location = new System.Drawing.Point(270, 490);
            this.tbx_mean4.Name = "tbx_mean4";
            this.tbx_mean4.Size = new System.Drawing.Size(245, 28);
            this.tbx_mean4.TabIndex = 3;
            // 
            // tbx_pronunciation
            // 
            this.tbx_pronunciation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbx_pronunciation.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_pronunciation.Location = new System.Drawing.Point(271, 245);
            this.tbx_pronunciation.Name = "tbx_pronunciation";
            this.tbx_pronunciation.Size = new System.Drawing.Size(245, 28);
            this.tbx_pronunciation.TabIndex = 0;
            // 
            // lb_pronunciation
            // 
            this.lb_pronunciation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_pronunciation.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lb_pronunciation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lb_pronunciation.Font = new System.Drawing.Font("Calibri", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pronunciation.Location = new System.Drawing.Point(154, 245);
            this.lb_pronunciation.Name = "lb_pronunciation";
            this.lb_pronunciation.Size = new System.Drawing.Size(92, 27);
            this.lb_pronunciation.TabIndex = 7;
            this.lb_pronunciation.Text = "Phát âm:";
            this.lb_pronunciation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PJ_Dictionary.Properties.Resources.NEn_tu_dien;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1010, 618);
            this.Controls.Add(this.lb_mean);
            this.Controls.Add(this.lb_wordType);
            this.Controls.Add(this.lb_pronunciation);
            this.Controls.Add(this.lb_word);
            this.Controls.Add(this.btn_updateFile);
            this.Controls.Add(this.btn_updateTree);
            this.Controls.Add(this.tbx_mean1);
            this.Controls.Add(this.tbx_mean4);
            this.Controls.Add(this.tbx_mean5);
            this.Controls.Add(this.tbx_mean2);
            this.Controls.Add(this.tbx_mean3);
            this.Controls.Add(this.tbx_pronunciation);
            this.Controls.Add(this.tbx_wordType);
            this.Controls.Add(this.tbx_word);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox tbx_word;
        public System.Windows.Forms.TextBox tbx_wordType;
        public System.Windows.Forms.TextBox tbx_mean3;
        public System.Windows.Forms.TextBox tbx_mean2;
        public System.Windows.Forms.TextBox tbx_mean1;
        public System.Windows.Forms.Button btn_updateTree;
        public System.Windows.Forms.Button btn_updateFile;
        public System.Windows.Forms.Label lb_word;
        public System.Windows.Forms.Label lb_wordType;
        public System.Windows.Forms.Label lb_mean;
        public System.Windows.Forms.TextBox tbx_mean5;
        public System.Windows.Forms.TextBox tbx_mean4;
        public System.Windows.Forms.TextBox tbx_pronunciation;
        public System.Windows.Forms.Label lb_pronunciation;
    }
}