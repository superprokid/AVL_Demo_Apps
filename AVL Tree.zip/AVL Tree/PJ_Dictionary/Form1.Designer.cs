﻿namespace PJ_Dictionary
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_Search = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.lb_WordType = new System.Windows.Forms.Label();
            this.lb_Mean1 = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.bt_mean1 = new System.Windows.Forms.Button();
            this.bt_mean2 = new System.Windows.Forms.Button();
            this.bt_mean3 = new System.Windows.Forms.Button();
            this.bt_mean4 = new System.Windows.Forms.Button();
            this.bt_mean5 = new System.Windows.Forms.Button();
            this.lb_Mean2 = new System.Windows.Forms.Label();
            this.lb_Mean3 = new System.Windows.Forms.Label();
            this.lb_Mean4 = new System.Windows.Forms.Label();
            this.lb_Mean5 = new System.Windows.Forms.Label();
            this.lb_Word = new System.Windows.Forms.Label();
            this.cbb_NhapTu = new System.Windows.Forms.ComboBox();
            this.btn_Speak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Search
            // 
            this.btn_Search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Search.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.Location = new System.Drawing.Point(731, 158);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(78, 28);
            this.btn_Search.TabIndex = 1;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.Btn_Search_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Delete.BackColor = System.Drawing.Color.White;
            this.btn_Delete.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.Red;
            this.btn_Delete.Location = new System.Drawing.Point(913, 237);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(71, 25);
            this.btn_Delete.TabIndex = 2;
            this.btn_Delete.Text = "Delele";
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Update.BackColor = System.Drawing.Color.White;
            this.btn_Update.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.Green;
            this.btn_Update.Location = new System.Drawing.Point(740, 237);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(71, 25);
            this.btn_Update.TabIndex = 3;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.Btn_Update_Click);
            // 
            // lb_WordType
            // 
            this.lb_WordType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_WordType.AutoSize = true;
            this.lb_WordType.BackColor = System.Drawing.Color.Transparent;
            this.lb_WordType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lb_WordType.Font = new System.Drawing.Font("Calibri", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_WordType.Location = new System.Drawing.Point(650, 284);
            this.lb_WordType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_WordType.Name = "lb_WordType";
            this.lb_WordType.Size = new System.Drawing.Size(66, 23);
            this.lb_WordType.TabIndex = 5;
            this.lb_WordType.Text = "Loại từ";
            // 
            // lb_Mean1
            // 
            this.lb_Mean1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mean1.AutoSize = true;
            this.lb_Mean1.BackColor = System.Drawing.Color.Transparent;
            this.lb_Mean1.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mean1.Location = new System.Drawing.Point(467, 330);
            this.lb_Mean1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Mean1.Name = "lb_Mean1";
            this.lb_Mean1.Size = new System.Drawing.Size(67, 23);
            this.lb_Mean1.TabIndex = 6;
            this.lb_Mean1.Text = "nghia 1";
            // 
            // btn_Add
            // 
            this.btn_Add.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Add.BackColor = System.Drawing.Color.White;
            this.btn_Add.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.Blue;
            this.btn_Add.Location = new System.Drawing.Point(817, 237);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(90, 25);
            this.btn_Add.TabIndex = 9;
            this.btn_Add.Text = "Add New";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(390, 266);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(594, 2);
            this.button1.TabIndex = 10;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // bt_mean1
            // 
            this.bt_mean1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_mean1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bt_mean1.Enabled = false;
            this.bt_mean1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_mean1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.bt_mean1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.bt_mean1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.bt_mean1.Location = new System.Drawing.Point(445, 330);
            this.bt_mean1.Margin = new System.Windows.Forms.Padding(2);
            this.bt_mean1.Name = "bt_mean1";
            this.bt_mean1.Size = new System.Drawing.Size(8, 28);
            this.bt_mean1.TabIndex = 11;
            this.bt_mean1.UseVisualStyleBackColor = false;
            // 
            // bt_mean2
            // 
            this.bt_mean2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_mean2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bt_mean2.Enabled = false;
            this.bt_mean2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_mean2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.bt_mean2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.bt_mean2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.bt_mean2.Location = new System.Drawing.Point(445, 376);
            this.bt_mean2.Margin = new System.Windows.Forms.Padding(2);
            this.bt_mean2.Name = "bt_mean2";
            this.bt_mean2.Size = new System.Drawing.Size(8, 28);
            this.bt_mean2.TabIndex = 11;
            this.bt_mean2.UseVisualStyleBackColor = false;
            // 
            // bt_mean3
            // 
            this.bt_mean3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_mean3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bt_mean3.Enabled = false;
            this.bt_mean3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_mean3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.bt_mean3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.bt_mean3.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.bt_mean3.Location = new System.Drawing.Point(445, 422);
            this.bt_mean3.Margin = new System.Windows.Forms.Padding(2);
            this.bt_mean3.Name = "bt_mean3";
            this.bt_mean3.Size = new System.Drawing.Size(8, 28);
            this.bt_mean3.TabIndex = 11;
            this.bt_mean3.UseVisualStyleBackColor = false;
            // 
            // bt_mean4
            // 
            this.bt_mean4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_mean4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bt_mean4.Enabled = false;
            this.bt_mean4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_mean4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.bt_mean4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.bt_mean4.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.bt_mean4.Location = new System.Drawing.Point(445, 469);
            this.bt_mean4.Margin = new System.Windows.Forms.Padding(2);
            this.bt_mean4.Name = "bt_mean4";
            this.bt_mean4.Size = new System.Drawing.Size(8, 28);
            this.bt_mean4.TabIndex = 11;
            this.bt_mean4.UseVisualStyleBackColor = false;
            // 
            // bt_mean5
            // 
            this.bt_mean5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_mean5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bt_mean5.Enabled = false;
            this.bt_mean5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_mean5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.bt_mean5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.bt_mean5.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.bt_mean5.Location = new System.Drawing.Point(445, 517);
            this.bt_mean5.Margin = new System.Windows.Forms.Padding(2);
            this.bt_mean5.Name = "bt_mean5";
            this.bt_mean5.Size = new System.Drawing.Size(8, 28);
            this.bt_mean5.TabIndex = 11;
            this.bt_mean5.UseVisualStyleBackColor = false;
            // 
            // lb_Mean2
            // 
            this.lb_Mean2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mean2.AutoSize = true;
            this.lb_Mean2.BackColor = System.Drawing.Color.Transparent;
            this.lb_Mean2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mean2.Location = new System.Drawing.Point(467, 376);
            this.lb_Mean2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Mean2.Name = "lb_Mean2";
            this.lb_Mean2.Size = new System.Drawing.Size(67, 23);
            this.lb_Mean2.TabIndex = 6;
            this.lb_Mean2.Text = "nghia 2";
            // 
            // lb_Mean3
            // 
            this.lb_Mean3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mean3.AutoSize = true;
            this.lb_Mean3.BackColor = System.Drawing.Color.Transparent;
            this.lb_Mean3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mean3.Location = new System.Drawing.Point(467, 422);
            this.lb_Mean3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Mean3.Name = "lb_Mean3";
            this.lb_Mean3.Size = new System.Drawing.Size(67, 23);
            this.lb_Mean3.TabIndex = 6;
            this.lb_Mean3.Text = "nghia 3";
            // 
            // lb_Mean4
            // 
            this.lb_Mean4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mean4.AutoSize = true;
            this.lb_Mean4.BackColor = System.Drawing.Color.Transparent;
            this.lb_Mean4.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mean4.Location = new System.Drawing.Point(467, 469);
            this.lb_Mean4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Mean4.Name = "lb_Mean4";
            this.lb_Mean4.Size = new System.Drawing.Size(67, 23);
            this.lb_Mean4.TabIndex = 6;
            this.lb_Mean4.Text = "nghia 4";
            // 
            // lb_Mean5
            // 
            this.lb_Mean5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mean5.AutoSize = true;
            this.lb_Mean5.BackColor = System.Drawing.Color.Transparent;
            this.lb_Mean5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mean5.Location = new System.Drawing.Point(467, 517);
            this.lb_Mean5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Mean5.Name = "lb_Mean5";
            this.lb_Mean5.Size = new System.Drawing.Size(67, 23);
            this.lb_Mean5.TabIndex = 6;
            this.lb_Mean5.Text = "nghia 5";
            // 
            // lb_Word
            // 
            this.lb_Word.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Word.BackColor = System.Drawing.Color.Transparent;
            this.lb_Word.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word.ForeColor = System.Drawing.Color.Blue;
            this.lb_Word.Location = new System.Drawing.Point(385, 239);
            this.lb_Word.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Word.Name = "lb_Word";
            this.lb_Word.Size = new System.Drawing.Size(261, 68);
            this.lb_Word.TabIndex = 4;
            this.lb_Word.Text = "Xin chào!";
            // 
            // cbb_NhapTu
            // 
            this.cbb_NhapTu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbb_NhapTu.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbb_NhapTu.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbb_NhapTu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_NhapTu.FormattingEnabled = true;
            this.cbb_NhapTu.IntegralHeight = false;
            this.cbb_NhapTu.ItemHeight = 22;
            this.cbb_NhapTu.Location = new System.Drawing.Point(429, 158);
            this.cbb_NhapTu.Margin = new System.Windows.Forms.Padding(2);
            this.cbb_NhapTu.Name = "cbb_NhapTu";
            this.cbb_NhapTu.Size = new System.Drawing.Size(296, 30);
            this.cbb_NhapTu.TabIndex = 1;
            this.cbb_NhapTu.SelectedValueChanged += new System.EventHandler(this.cbb_NhapTu_SelectedValueChanged);
            this.cbb_NhapTu.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbb_NhapTu_KeyDown);
            // 
            // btn_Speak
            // 
            this.btn_Speak.Font = new System.Drawing.Font("Times New Roman", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Speak.ForeColor = System.Drawing.Color.Fuchsia;
            this.btn_Speak.Location = new System.Drawing.Point(656, 237);
            this.btn_Speak.Name = "btn_Speak";
            this.btn_Speak.Size = new System.Drawing.Size(75, 25);
            this.btn_Speak.TabIndex = 12;
            this.btn_Speak.Text = "Speak";
            this.btn_Speak.UseVisualStyleBackColor = false;
            this.btn_Speak.Click += new System.EventHandler(this.btn_Speak_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PJ_Dictionary.Properties.Resources.NEn_tu_dien;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1155, 567);
            this.Controls.Add(this.btn_Speak);
            this.Controls.Add(this.cbb_NhapTu);
            this.Controls.Add(this.lb_WordType);
            this.Controls.Add(this.bt_mean5);
            this.Controls.Add(this.bt_mean4);
            this.Controls.Add(this.bt_mean3);
            this.Controls.Add(this.bt_mean2);
            this.Controls.Add(this.bt_mean1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.lb_Mean5);
            this.Controls.Add(this.lb_Mean4);
            this.Controls.Add(this.lb_Mean3);
            this.Controls.Add(this.lb_Mean2);
            this.Controls.Add(this.lb_Mean1);
            this.Controls.Add(this.lb_Word);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Search);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AVL Dictionary";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Button btn_Search;
        public System.Windows.Forms.Button btn_Delete;
        public System.Windows.Forms.Button btn_Update;
        public System.Windows.Forms.Label lb_WordType;
        public System.Windows.Forms.Label lb_Mean1;
        public System.Windows.Forms.Button btn_Add;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button bt_mean1;
        public System.Windows.Forms.Button bt_mean2;
        public System.Windows.Forms.Button bt_mean3;
        public System.Windows.Forms.Button bt_mean4;
        public System.Windows.Forms.Button bt_mean5;
        public System.Windows.Forms.Label lb_Mean2;
        public System.Windows.Forms.Label lb_Mean3;
        public System.Windows.Forms.Label lb_Mean4;
        public System.Windows.Forms.Label lb_Mean5;
        public System.Windows.Forms.Label lb_Word;
        public System.Windows.Forms.ComboBox cbb_NhapTu;
        private System.Windows.Forms.Button btn_Speak;
    }
}

