﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;


namespace TreeAVL
{
   public  class Node
    {
        public int Blance;             // Chi so can bang
        public int key;                // Gia tri cua khoa
        public Node pLeft;             // Node trai
        public Node pRight;            // Node phai
        public float x, y, Father;

        public Node(int key)
        {
            this.key = key;
            pLeft = null;
            pRight = null;
            Blance = 0;
        }
        public Node()
        {
            pLeft = null;
            pRight = null;
            Blance = 0;
        }

        public Node(int key, Node pLeft, Node pRight)
        {
            this.key = key;
            this.pLeft = pLeft;
            this.pRight = pRight;
            Blance = 0;
        }

        public void GetPos(Node node, Form1 f)
        {
            if (node != null)
            {
                GetNodePos(node, f);
                node.GetPos(node.pLeft, f);
                node.GetPos(node.pRight, f);
            }
        }

        private void GetNodePos(Node node, Form1 f)
        {
            if (node.key > key)
            {
                node.x = x + Convert.ToInt32(Math.Abs((x - Father) / 2));//XÁC ĐỊNH X, Y CỦA NODE PHẢI                
            }
            else
            {
                node.x = x - Convert.ToInt32(Math.Abs((x - Father) / 2));//XÁC ĐỊNH X, Y CỦA NODE TRÁI
            }
            node.y = y + 80;
            node.Father = x;
        }
    }
}
